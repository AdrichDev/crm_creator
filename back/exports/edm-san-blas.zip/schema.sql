-- Esquema generado para: EDM San Blas

-- Vertical: centro-deportivo | Módulos: clientes, servicios, citas, fichaje, productos, ventas, facturas, marketing

-- Generado: 2026-07-07T10:51:34.895Z

-- Núcleo multi-tenant
create extension if not exists "pgcrypto";
create schema if not exists app;

create or replace function app.set_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at := now(); return new; end; $$;

create table if not exists app.tenants (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text unique,
  vertical text not null default 'custom',
  phone text, email text, address text,
  brand_primary text not null default '#1b431c',
  brand_secondary text not null default '#8cc63f',
  brand_logo_text text,
  setup_complete boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists app.tenant_modules (
  tenant_id uuid not null references app.tenants(id) on delete cascade,
  module text not null,
  enabled boolean not null default true,
  primary key (tenant_id, module)
);

create or replace function app.user_tenant_ids()
returns setof uuid language sql stable security definer set search_path = app as $$
  select tenant_id from app.tenant_modules where false; -- reemplazar por memberships al añadir auth
$$;

create or replace function app.enable_tenant_rls(p_table regclass)
returns void language plpgsql as $$
begin
  execute format('alter table %s enable row level security', p_table);
  execute format($f$
    drop policy if exists tenant_isolation on %1$s;
    create policy tenant_isolation on %1$s
      using (tenant_id in (select app.user_tenant_ids()))
      with check (tenant_id in (select app.user_tenant_ids()));
  $f$, p_table);
end; $$;

create table if not exists app.clientes (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references app.tenants(id) on delete cascade,
  nombre text not null,
  email text,
  telefono text,
  segmento text default 'Nuevo',
  visitas integer not null default 0,
  gasto_total numeric(12,2) not null default 0,
  ultima_visita date,
  notas text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_clientes_tenant on app.clientes(tenant_id);
drop trigger if exists trg_clientes_updated on app.clientes;
create trigger trg_clientes_updated before update on app.clientes
  for each row execute function app.set_updated_at();
select app.enable_tenant_rls('app.clientes');

create table if not exists app.servicios (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references app.tenants(id) on delete cascade,
  nombre text not null,
  categoria text,
  duracion_min integer not null default 30,
  precio numeric(12,2) not null default 0,
  activo boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_servicios_tenant on app.servicios(tenant_id);
drop trigger if exists trg_servicios_updated on app.servicios;
create trigger trg_servicios_updated before update on app.servicios
  for each row execute function app.set_updated_at();
select app.enable_tenant_rls('app.servicios');

create table if not exists app.citas (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references app.tenants(id) on delete cascade,
  cliente_id uuid,
  servicio_id uuid,
  empleado_id uuid,
  cliente_nombre text,
  servicio_nombre text,
  empleado_nombre text,
  fecha date not null,
  hora time,
  estado text not null default 'Pendiente',
  notas text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_citas_tenant on app.citas(tenant_id);
drop trigger if exists trg_citas_updated on app.citas;
create trigger trg_citas_updated before update on app.citas
  for each row execute function app.set_updated_at();
select app.enable_tenant_rls('app.citas');

create table if not exists app.fichajes (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references app.tenants(id) on delete cascade,
  empleado_id uuid,
  empleado_nombre text,
  fecha date not null default current_date,
  entrada timestamptz,
  salida timestamptz,
  horas numeric(5,2),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_fichajes_tenant on app.fichajes(tenant_id);
drop trigger if exists trg_fichajes_updated on app.fichajes;
create trigger trg_fichajes_updated before update on app.fichajes
  for each row execute function app.set_updated_at();
select app.enable_tenant_rls('app.fichajes');

create table if not exists app.productos (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references app.tenants(id) on delete cascade,
  nombre text not null,
  categoria text,
  stock integer not null default 0,
  stock_minimo integer not null default 0,
  precio numeric(12,2) not null default 0,
  proveedor text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_productos_tenant on app.productos(tenant_id);
drop trigger if exists trg_productos_updated on app.productos;
create trigger trg_productos_updated before update on app.productos
  for each row execute function app.set_updated_at();
select app.enable_tenant_rls('app.productos');

create table if not exists app.ventas (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references app.tenants(id) on delete cascade,
  cliente_id uuid,
  cliente_nombre text default 'Contado',
  fecha date not null default current_date,
  metodo_pago text not null default 'Tarjeta',
  total numeric(12,2) not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_ventas_tenant on app.ventas(tenant_id);
drop trigger if exists trg_ventas_updated on app.ventas;
create trigger trg_ventas_updated before update on app.ventas
  for each row execute function app.set_updated_at();
select app.enable_tenant_rls('app.ventas');

create table if not exists app.facturas (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references app.tenants(id) on delete cascade,
  numero text not null,
  cliente_id uuid,
  cliente_nombre text,
  fecha date not null default current_date,
  total numeric(12,2) not null default 0,
  estado text not null default 'Pendiente',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_facturas_tenant on app.facturas(tenant_id);
drop trigger if exists trg_facturas_updated on app.facturas;
create trigger trg_facturas_updated before update on app.facturas
  for each row execute function app.set_updated_at();
select app.enable_tenant_rls('app.facturas');

create table if not exists app.documentos (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references app.tenants(id) on delete cascade,
  nombre text not null,
  tipo text,
  tam integer,
  fecha date not null default current_date,
  factura_id uuid,
  cliente_id uuid,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_documentos_tenant on app.documentos(tenant_id);
drop trigger if exists trg_documentos_updated on app.documentos;
create trigger trg_documentos_updated before update on app.documentos
  for each row execute function app.set_updated_at();
select app.enable_tenant_rls('app.documentos');

create table if not exists app.campanas (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references app.tenants(id) on delete cascade,
  nombre text not null,
  canal text not null default 'Email',
  estado text not null default 'Borrador',
  enviados integer not null default 0,
  aperturas text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_campanas_tenant on app.campanas(tenant_id);
drop trigger if exists trg_campanas_updated on app.campanas;
create trigger trg_campanas_updated before update on app.campanas
  for each row execute function app.set_updated_at();
select app.enable_tenant_rls('app.campanas');

-- Relaciones entre módulos

alter table app.citas drop constraint if exists fk_citas_cliente;
alter table app.citas add constraint fk_citas_cliente
  foreign key (cliente_id) references app.clientes(id) on delete set null;

alter table app.citas drop constraint if exists fk_citas_servicio;
alter table app.citas add constraint fk_citas_servicio
  foreign key (servicio_id) references app.servicios(id) on delete set null;

alter table app.ventas drop constraint if exists fk_ventas_cliente;
alter table app.ventas add constraint fk_ventas_cliente
  foreign key (cliente_id) references app.clientes(id) on delete set null;

alter table app.facturas drop constraint if exists fk_facturas_cliente;
alter table app.facturas add constraint fk_facturas_cliente
  foreign key (cliente_id) references app.clientes(id) on delete set null;

alter table app.documentos drop constraint if exists fk_documentos_factura;
alter table app.documentos add constraint fk_documentos_factura
  foreign key (factura_id) references app.facturas(id) on delete set null;

alter table app.documentos drop constraint if exists fk_documentos_cliente;
alter table app.documentos add constraint fk_documentos_cliente
  foreign key (cliente_id) references app.clientes(id) on delete set null;
